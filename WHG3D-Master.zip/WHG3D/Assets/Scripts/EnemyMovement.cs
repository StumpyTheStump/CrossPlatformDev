﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyMovement : MonoBehaviour {

	public Transform[] points;
	private int destPoint = 0;
	private NavMeshAgent enemyAgent;

	// Use this for initialization
	void Start () 
	{
		enemyAgent = GetComponent<NavMeshAgent>();
		enemyAgent.autoBraking = false;	
	}

	void GotoNextPoint()
	{
		if(points.Length == 0)
			return;

			enemyAgent.destination = points[destPoint].position;
	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}
}
