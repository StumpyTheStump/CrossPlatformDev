﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {

	public float speed = 10.0f; 

	// Use this for initialization
	void Start () 
	{
		Cursor.lockState = CursorLockMode.Locked;
	}
	
	// Update is called once per frame
	void Update () 
	{
		float VerticalAxis = Input.GetAxis("Vertical") * speed;
		float HorizontalAxis = Input.GetAxis("Horizontal") * speed;
		VerticalAxis *= Time.deltaTime;
		HorizontalAxis *= Time.deltaTime;

		transform.Translate(HorizontalAxis, 0 , VerticalAxis);

		if (Input.GetKeyDown(KeyCode.Escape))
		Cursor.lockState = CursorLockMode.None;

	}
}
