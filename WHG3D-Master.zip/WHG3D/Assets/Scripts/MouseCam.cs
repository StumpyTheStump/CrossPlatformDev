﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseCam : MonoBehaviour 
{
	Vector2 mouseLook;
	Vector2 mouseSmooth;
	public float sensitivity = 5.0f;
	public float smoothing = 2.0f;

	GameObject Player;

	// Use this for initialization
	void Start () 
	{
		Player = this.transform.parent.gameObject;
	}
	
	// Update is called once per frame
	void Update () 
	{
		var mouseMovement = new Vector2(Input.GetAxisRaw("Mouse X"), Input.GetAxisRaw("Mouse Y"));

		mouseMovement = Vector2.Scale(mouseMovement, new Vector2(sensitivity * smoothing, sensitivity * smoothing));
		mouseSmooth.x = Mathf.Lerp(mouseSmooth.x, mouseMovement.x, 1.0f / smoothing);
		mouseSmooth.y = Mathf.Lerp(mouseSmooth.y, mouseMovement.y, 1.0f / smoothing);
		mouseLook += mouseSmooth;
		mouseLook.y = Mathf.Clamp(mouseLook.y, -90, 90);

		transform.localRotation = Quaternion.AngleAxis(-mouseLook.y, Vector3.right);
		Player.transform.localRotation = Quaternion.AngleAxis(mouseLook.x, Player.transform.up);

		
	}
}
